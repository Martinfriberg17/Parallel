package cloudscapes;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.util.Vector;
import java.io.FileWriter;
import java.io.PrintWriter;


public class CloudData {

	MyVector [][][] advection;// in-plane regular grid of wind vectors, that evolve over time
	MyVector averageWind;
	double [][][] convection; // vertical air movement strength, that evolves over time
	int [][][] classification; // cloud type per grid point, evolving over time
	int dimx, dimy, dimt; // data dimensions
double [][] wind;
	// overall number of elements in the timeline grids
	int dim(){
		return dimt*dimx*dimy;
	}
	
	// convert linear position into 3D location in simulation grid
	void locate(int pos, int [] ind)
	{
		ind[0] = (int) pos / (dimx*dimy); // t
		ind[1] = (pos % (dimx*dimy)) / dimy; // x
		ind[2] = pos % (dimy); // y
	}
	
	public void windAverageSequential(){
		double totalWindY = 0;
		double totalWindX = 0;
		double averageWindX = 0;
		double averageWindY = 0;
		for(int t = 0; t < dimt; t++) {
			for(int x = 0; x < dimx; x++) {
				for(int y = 0; y < dimy; y++){
					totalWindY += advection[t][x][y].y;
					totalWindX += advection[t][x][y].x;
				}
			}
		}
		averageWindX = totalWindX/(double)dim();
		averageWindY = totalWindY/(double)dim();
		averageWind = new MyVector();
		averageWind.x = averageWindX;
		averageWind.y = averageWindY;
	}
	
	public void CalculateOutputCode () {
		int numberOfElements = 0;
		double totalWind = 0;
		double averageWind;
		int count =0;
		for(int t = 0; t < dimt; t++) {
			for(int x = 0; x < dimx; x++) {
				for(int y = 0; y < dimy; y++){
					if ((count % 10000)==0) {
						System.out.println(count + "calc");
					}
					for (int counterX = 0; counterX<dimx; counterX++) {
						for (int counterY = 0; counterY < dimy; counterY++) {
							if ((x + counterX - 1) >= 0 && (x + counterX -1) < dimx 
									&& (y + counterY - 1) >= 0 && (y + counterY -1) <dimy) {
								totalWind += advection [t][x + counterX-1][y + counterY-1].x;
								totalWind += advection [t][x + counterX-1][y + counterY-1].y;
								numberOfElements += 2;
							}
							
						}
					}
					count ++;
					averageWind = totalWind /(double)numberOfElements;
					if (averageWind>Math.abs(convection[t][x][y]) && averageWind > 0.2) {
						classification[t][x][y] = 1;
					}else if (Math.abs(convection[t][x][y]) > averageWind){
						classification[t][x][y] = 0;
					}else {
						classification[t][x][y] = 2;
					}
					totalWind = 0;
					numberOfElements = 0;
				}
			}
		}
	}
	
	// read cloud simulation data from file
	void readData(String fileName){ 
		try{ 
			Scanner sc = new Scanner(new File(fileName), "UTF-8");
			
			// input grid dimensions and simulation duration in timesteps
			dimt = sc.nextInt();
			dimx = sc.nextInt(); 
			dimy = sc.nextInt();
			//sc.nextLine();
			
			// initialize and load advection (wind direction and strength) and convection
			advection = new MyVector[dimt][dimx][dimy];
			convection = new double [dimt][dimx][dimy];
			int hej = 0;
			for(int t = 0; t < dimt; t++)
				for(int x = 0; x < dimx; x++)
					for(int y = 0; y < dimy; y++){
						if ((hej % 100000)==0) {
System.out.println(Integer.toString(hej) + "K");
						}
						advection[t][x][y] = new MyVector();
						advection[t][x][y].x = sc.nextDouble();
						advection[t][x][y].y = sc.nextDouble();
						convection[t][x][y] = sc.nextDouble();
						hej ++;
					}
			
			classification = new int[dimt][dimx][dimy];
			sc.close(); 
		} 
		catch (IOException e){ 
			System.out.println("Unable to open input file "+fileName);
			e.printStackTrace();
		}
		catch (java.util.InputMismatchException e){ 
			System.out.println("Malformed input file "+fileName);
			e.printStackTrace();
		}
	}

	
	// write classification output to file
	void writeData(String fileName/** MyVector wind**/){
		 try{ 

			 FileWriter fileWriter = new FileWriter(fileName);
			 PrintWriter printWriter = new PrintWriter(fileWriter);
			 printWriter.printf("%d %d %d\n", dimt, dimx, dimy);
			 printWriter.printf("%f %f\n", averageWind.x, averageWind.y);
			 for(int t = 0; t < dimt; t++){
				 for(int x = 0; x < dimx; x++){
					for(int y = 0; y < dimy; y++){
						printWriter.printf("%d ", classification[t][x][y]);
					}
				 }
				 printWriter.printf("\n");
		     }
				 
			 printWriter.close();
		 }
		 catch (IOException e){
			 System.out.println("Unable to open output file "+fileName);
				e.printStackTrace();
		 }
	}
}